import HalftoneWaves from "@/components/halftone-waves"

export default function Home() {
  return (
    <main>
      <HalftoneWaves />
    </main>
  )
}
